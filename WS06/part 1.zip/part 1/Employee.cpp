#include "Employee.h"

using namespace std;
namespace sdds
{
    Employee::Employee(std::istream &is)
    {
        bool valid = true;
        char c{};
        std::string proxyString{};
        for (int i = 0; i < 3; i++)
        {
            proxyString.clear();
            valid = true;
            while (valid && is)
            {
                c = is.get();
                if (c == '\n' || c == ','||c==-1)
                {
                    valid = false;
                }
                else
                {
                    if (c != ' ')
                    {
                        proxyString += c;
                    }
                }
            }
            switch (i)
            {
            case 0:
            {
                // setting name
                // cout << proxyString << endl;
                m_name = proxyString;
                break;
            }
            case 1:
            {
                // setting age
                // cout << proxyString << endl;
                m_age = proxyString;
                break;
            }
            case 2:
            {
                // cout << proxyString << endl;
                // cout<<proxyString[0]<<endl;
                // setting employee id
                if (proxyString[0] == 'e' || proxyString[0] == 'E')
                {
                    m_id = proxyString;
                }
                else
                {
                    std::string message = m_name + "++Invalid record!";
                    throw message;
                }
                break;
            }
            default:
            {
                break;
            }
            }
        }
    }
    std::string Employee::status() const
    {
        return "Employee";
    }
    std::string Employee::name() const
    {
        return m_name;
    }
    std::string Employee::id() const
    {
        return m_id;
    }
    std::string Employee::age() const
    {
        return m_age;
    }
    void Employee::display(std::ostream &out) const
    {
        out.setf(ios::left);
        out << "| ";
        out.width(10);
        out << "Employee";
        out << " | ";
        out.width(10);
        out << m_id;
        out << " | ";
        out.width(20);
        out << m_name;
        out << " | ";
        out.width(3);
        out << m_age;
        out << " |" << endl;
        out.unsetf(ios::left);
    }
}
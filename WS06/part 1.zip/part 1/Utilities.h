#ifndef SDDS_UTILITIES_H
#define SDDS_UTILITIES_H
#include <iostream>
#include "Person.h"
#include"Employee.h"
namespace sdds
{
    Person *buildInstance(std::istream &in);
}
#endif
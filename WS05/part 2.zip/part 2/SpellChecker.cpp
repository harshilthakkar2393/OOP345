#include "SpellChecker.h"
using namespace std;
namespace sdds
{
    SpellChecker::SpellChecker(const char *filename)
    {
        int goodCount = 0;
        int badCount = 0;
        std::ifstream file(filename);
        if (!file)
        {
            throw "Bad file name!";
        }
        else
        {
            for (int i = 0; i < 12; i++)
            {
                if ((i + 1) % 2 == 0)
                {
                    file >> m_goodWords[goodCount];
                    goodCount++;
                }
                else
                {
                    file >> m_badWords[badCount];
                    badCount++;
                }
            }
            file.close();
        }
    }
    void SpellChecker::operator()(std::string &text)
    {
        for (int i = 0; i < 6; i++)
        {
            bool found = true;
            while (found)
            {
                size_t index = text.find(m_badWords[i]);
                if (index == size_t(-1))
                {
                    found = false;
                }
                else
                {
                    text.replace(index, m_badWords[i].length(), m_goodWords[i]);
                    replaceCount[i]++;
                }
            }
        }
    }
    void SpellChecker::showStatistics(std::ostream &out) const
    {
        for (int i = 0; i < 6; i++)
        {
            out.setf(ios::right);
            out.width(15);
            out << m_badWords[i];
            out.unsetf(ios::right);
            out << ": " << replaceCount[i] << " replacements" << endl;
        }
    }
}